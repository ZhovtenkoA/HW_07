import sys 
from pathlib import Path
sorting_direction = Path(sys.argv[1])